from fastapi import FastAPI, Depends, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
import pandas as pd
from retry import retry
#from InputModel import validate_address
import requests
import json
from pydantic import BaseModel, ValidationError, validator
# Import global exception handler
from middleware.global_exception_handler import CustomException, RetryableHttpException, global_exception_handler

# Import authorization-related code
from middleware.authorization import Authorization, validate_token

# Import appinsight logger
from middleware.appinsight import log_exception, appinsights_middleware

# Import blob storage functions
from middleware.blob_storage_handler import BlobStorage, download_csv, upload_csv

app = FastAPI()

# Define CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add middleware
app.add_middleware(appinsights_middleware)

# Register global exception handler
app.add_exception_handler(Exception, global_exception_handler)

# Define input model
class InputModel(BaseModel):
    id: int
    name: str
    address: str
    
    @validator('address')
    def validate_address(cls, value):
        if not value.isalpha():
            raise ValueError('Invalid address')
        return value

# Define function to get connection string from Azure Key Vault
def get_connection_string_from_key_vault():
    # Set up key vault client
    credential = DefaultAzureCredential()
    key_vault_uri = f"https://{os.environ['AZURE_KEY_VAULT_NAME']}.vault.azure.net"
    secret_client = SecretClient(vault_url=key_vault_uri, credential=credential)
    # Get connection string secret
    connection_string_secret = secret_client.get_secret(os.environ["AZURE_STORAGE_CONNECTION_STRING_SECRET_NAME"])
    return connection_string_secret.value

# Define function to get blob client
def get_blob_client(container_name: str):
    # Get connection string from environment variables
    connection_string = get_connection_string_from_key_vault()
    # Create blob client
    blobStorage = BlobStorage(connection_string, container_name)    
    # blob_client = blobStorage.container_client.get_blob_client(blob_name)
    return blobStorage

# Define endpoint
@app.get("/endpoint/{id}")
async def endpoint(
    id: int,
    input_model: InputModel,
    authorization: Optional[str] = Header(None), #remove optional when we deploy the code, it's just for the debugging purposes
    #user_id: str = Depends(get_user_id_from_token),
):
    try:
        auth = Authorization(authorization).validate_token()        
        user_name = auth.name
        user_email = auth.email
        user_group = auth.group
         # Validate token
        # validate_token(authorization)        
        # Validate input       
        # Validate the address field
        try:
            validate_address(input_model.address)
        except ValueError as e:
            raise CustomException(DeveloperMessage=str(e), UserMessage="Invalid address", status_code=400)
    
       
        # Call external API to get additional data
        api_response = requests.get(os.environ["EXTERNAL_API_URL"]).json()
        additional_data = {
            "id": api_response.get("id"),
            "name": api_response.get("name"),
            "address": api_response.get("address"),
        }
        # Validate additional data
        if not additional_data["address"].isalnum():
            raise RetryableHttpException(
                status_code=500,
                developer_message="Invalid address in external API response",
                user_message="There was an error processing your request. Please try again later.",
            )
        # Download file from blob storage
        blobStorage = get_blob_client("container-name")
        df = blobStorage.download(f"{id}.csv")
        df["new_column"] = input_model.class_
        # Upload updated file to blob storage        
        blobStorage.upload(f"{id}.csv",df)
        # Return response
        return {
            "message": "File updated successfully",
            "additional_data": additional_data,
        }
    except Exception as e:
        # Log exception using appinsight_logger
        log_exception(e)
        # Handle exception using global_exception_handler
        return global_exception_handler(e)
    
# Define endpoint with id in the route and class as input parameters
@app.post("/process/{id}")
async def process_data(id: int, input_data: InputModel): # example to read a claim from the token, user_id: str = Depends(get_user_id_from_token)):
    # Validate token
  
    #validate_token()
    
    # Call API to retrieve JSON object with id, name and address
    @retry(tries=3, delay=1)
    def call_api():
        response = requests.get("https://example.com/api/data")
        if response.status_code == 200:
            data = json.loads(response.content)
            # Validate address
            if not validate_address(data["address"]):
                raise CustomException(status_code=400, developer_message="Invalid address", user_message="Please enter a valid address")
            return data
        elif response.status_code >= 500:
            raise RetryableHttpException(status_code=response.status_code, developer_message="Server error", user_message="Please try again later")
        else:
            raise HttpException(status_code=response.status_code, developer_message="Unexpected error", user_message="An unexpected error occurred")
    
    try:
        data = call_api()
    except Exception as e:
        log_exception(e)
        raise global_exception_handler(e)
    
    return {"message": "File processed successfully"}    
