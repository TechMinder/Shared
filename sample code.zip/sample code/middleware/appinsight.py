from applicationinsights import TelemetryClient 
import logging
from fastapi import Request
import logging
import os
from azure.monitor.opentelemetry.exporter import AzureMonitorTraceExporter
from opentelemetry import trace
from opentelemetry.ext.azure.log_exporter import AzureLogHandler
from fastapi import Request
from applicationinsights import TelemetryClient
from starlette.middleware.base import BaseHTTPMiddleware


# create telemetry client for app insights
tc = TelemetryClient(os.environ.get("APPINSIGHTS_INSTRUMENTATIONKEY"))


def appinsights_middleware(app):
    async def middleware(request: Request, call_next):
        try:
            response = await call_next(request)
            # log successful request
            tc.track_request(
                request.method,
                request.url.path,
                response.status_code,
                round(response.elapsed.total_seconds() * 1000),
                response.status_code < 400
            )
        except Exception as e:
            # log failed request
            tc.track_exception()
            logging.exception(str(e))
            raise
        finally:
            tc.flush()
        return response

    return middleware


# Set up tracing and logging
logger = logging.getLogger(__name__)
logger.addHandler(AzureLogHandler(connection_string=os.environ["APPINSIGHTS_CONNECTION_STRING"]))

# Define function to log exception
def log_exception(exception):
    logger.exception(exception)
