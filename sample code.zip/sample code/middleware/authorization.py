from typing import Optional
import os
import jwt
from fastapi import HTTPException
import time



class Authorization:
    def __init__(self, jwt_token):
        self.jwt_token = jwt_token
        

    def validate_token(self):      
        if not self.jwt_token:
            raise HTTPException(status_code=401, detail="Authorization header is missing")
        try:
            token = self.jwt_token.split()[1]
            claims = jwt.decode(token, algorithms=["RS256"], options={"verify_signature": False})
            
        except (jwt.exceptions.DecodeError, jwt.exceptions.ExpiredSignatureError):
            raise HTTPException(status_code=401, detail="Invalid token")    
       
        # Validate claims
        if not claims.get("aud") == os.environ["AZURE_APP_ID_URI"]:
            raise HTTPException(status_code=401, detail="Invalid audience")
        if not claims.get("iss") == os.environ["AZURE_ISSUER"]:
            raise HTTPException(status_code=401, detail="Invalid issuer")
        if not claims.get("exp") > time.time():
            raise HTTPException(status_code=401, detail="Token expired")  
        
        self.claims = self.validate_token()
        self.name = self.claims.get("name")
        self.email = self.claims.get("email")
        self.group = self.claims.get("group")
        
        
        
    # def get_user_id(token: str):
    #     # Extract claims from Azure AD bearer JWT token
    #     claims = token.split('.')[1]
    #     padding = '=' * (4 - (len(claims) % 4))
    #     claims += padding
    #     user_id = None
    #     try:
    #         decoded = base64.b64decode(claims)
    #         user_id = json.loads(decoded)['oid']
    #     except (TypeError, KeyError, json.JSONDecodeError):
    #         pass
    #     return user_id

    # # Define function to get user id from token
    # def get_user_id_from_token(authorization: Optional[str] = Header(None)):
    #     if not authorization:
    #         raise HTTPException(status_code=401, detail="Authorization header missing")
    #     token = authorization.split()[1]
    #     try:
    #         claims = jwt.decode(token, verify=False)
    #         return claims.get("userid")
    #     except Exception:
    #         raise HTTPException(status_code=401, detail="Invalid token")

   