'''
we are using the @retrying.retry decorator to add retry logic to the download and upload methods.
We are retrying a maximum of 3 times with a fixed wait time of 2 seconds between each retry.
We are also catching any exception raised during the download or upload operation and re-raising it for the global exception handler to handle.
Note that we are not logging the exceptions inside the BlobStorage class. 
Instead, we are letting the global exception handler handle the exceptions and log them using the appinsight logger.
'''
import pandas as pd
from azure.storage.blob import BlobServiceClient
import retrying

class BlobStorage:
    def __init__(self, connection_string, container_name):
        self.blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        self.container_client = self.blob_service_client.get_container_client(container_name)

    @retrying.retry(wait_fixed=2000, stop_max_attempt_number=3)
    def download(self, blob_name):
        blob_client = self.container_client.get_blob_client(blob_name)
        try:
            stream = blob_client.download_blob().content_as_text()
            df = pd.read_csv(stream)
            return df
        except Exception as e:
            raise e

    @retrying.retry(wait_fixed=2000, stop_max_attempt_number=3)
    def upload(self, blob_name, df):
        blob_client = self.container_client.get_blob_client(blob_name)
        try:
            csv_data = df.to_csv(index=False)
            blob_client.upload_blob(csv_data, overwrite=True)
        except Exception as e:
            raise e
