from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
from appinsight import log_exception
from typing import List

# Define exception class
class CustomException(Exception):
    def __init__(self, status_code: int, developer_message: str, user_message: str):
        self.status_code = status_code
        self.developer_message = developer_message
        self.user_message = user_message

# Define retryable HTTP exception class
class RetryableHttpException(Exception):
    def __init__(self, status_code: int, developer_message: str, user_message: str):
        self.status_code = status_code
        self.developer_message = developer_message
        self.user_message = user_message

# Define global exception handler
def global_exception_handler(request, exception):
    # Log exception
    log_exception(exception)

    # Handle RequestValidationError
    if isinstance(exception, RequestValidationError):
        return {"detail": exception.errors(), "body": exception.body, "status_code": 422}

    # Handle HTTPException
    if isinstance(exception, StarletteHTTPException):
        return {"detail": exception.detail, "status_code": exception.status_code}

    # Handle CustomException
    if isinstance(exception, CustomException):
        return {"detail": exception.user_message, "status_code": exception.status_code}

    # Handle RetryableHttpException
    if isinstance(exception, RetryableHttpException):
        return {"detail": exception.user_message, "status_code": exception.status_code}

    # Handle other exceptions
    return {"detail": "An unexpected error occurred", "status_code": 500}
